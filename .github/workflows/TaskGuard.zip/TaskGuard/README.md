# TaskGuard
1. Installa Shizuku dal Play Store/GitHub e avvialo (Opzioni sviluppatore > Debug wireless > "Avvia" nell'app Shizuku).
2. Apri la cartella in Android Studio, sincronizza Gradle, esegui su Pixel 7a.
3. In TaskGuard tocca "Autorizza" e concedi il permesso Shizuku.

## Build su GitHub
1. Crea un repo vuoto e carica tutto il contenuto di questa cartella (incluso `.github/`).
2. Vai su **Actions > Build APK**: parte da solo al push (o con "Run workflow").
3. A build finita scarica l'APK da **Artifacts > TaskGuard-debug**.
4. Per una Release con APK allegato: `git tag v1.0 && git push --tags`.
L'APK debug è firmato con la chiave di debug, quindi si installa direttamente.
