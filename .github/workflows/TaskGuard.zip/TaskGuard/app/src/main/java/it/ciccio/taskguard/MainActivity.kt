package it.ciccio.taskguard

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var ok by remember { mutableStateOf(Sh.ready()) }
    DisposableEffect(Unit) {
        val l = Shizuku.OnRequestPermissionResultListener { _, _ -> ok = Sh.ready() }
        Shizuku.addRequestPermissionResultListener(l)
        onDispose { Shizuku.removeRequestPermissionResultListener(l) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        if (!ok) Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Shizuku non attivo o permesso mancante", Modifier.weight(1f))
            Button(onClick = {
                try {
                    if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
                    else Toast.makeText(ctx, "Avvia prima Shizuku", Toast.LENGTH_LONG).show()
                } catch (e: Throwable) { Toast.makeText(ctx, "Shizuku non trovato", Toast.LENGTH_LONG).show() }
                ok = Sh.ready()
            }) { Text("Autorizza") }
        }
        TabRow(selectedTabIndex = tab) {
            listOf("Salute", "Processi", "Autostart").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }) { Text(t, Modifier.padding(12.dp)) }
            }
        }
        when (tab) { 0 -> Health(); 1 -> Procs(ok); else -> BootTab(ok) }
    }
}

@Composable
fun Info(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
    Text(k, Modifier.weight(1f)); Text(v)
}

@Composable
fun Health() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(3000); tick++ } }
    val rows = remember(tick) {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = (b?.getIntExtra("level", 0) ?: 0) * 100 / (b?.getIntExtra("scale", 100) ?: 100)
        val temp = (b?.getIntExtra("temperature", 0) ?: 0) / 10.0
        val health = when (b?.getIntExtra("health", 1)) {
            2 -> "Buona"; 3 -> "Surriscaldata"; 4 -> "Esaurita"; 5 -> "Sovratensione"; else -> "Sconosciuta"
        }
        val charging = (b?.getIntExtra("plugged", 0) ?: 0) != 0
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ramTot = mi.totalMem / 1048576
        val ramUsed = ramTot - mi.availMem / 1048576
        val sf = StatFs(Environment.getDataDirectory().path)
        val stTot = sf.totalBytes / 1073741824.0
        val stUsed = stTot - sf.availableBytes / 1073741824.0
        listOf(
            "Batteria" to "$lvl%" + if (charging) " (in carica)" else "",
            "Temperatura batteria" to "%.1f °C".format(temp),
            "Salute batteria" to health,
            "RAM" to "$ramUsed / $ramTot MB",
            "Archiviazione" to "%.1f / %.1f GB".format(stUsed, stTot),
        )
    }
    Column(Modifier.padding(top = 8.dp)) { rows.forEach { (k, v) -> Info(k, v); HorizontalDivider() } }
}

@Composable
fun Procs(ok: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<Proc>()) }
    fun refresh() { if (ok) scope.launch { list = loadProcs(ctx) } }
    LaunchedEffect(ok) { refresh() }
    Column {
        Button(onClick = { refresh() }, modifier = Modifier.padding(8.dp)) { Text("Aggiorna") }
        LazyColumn {
            items(list, key = { it.pkg }) { p ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.label)
                        Text("${p.pkg} · ${p.mb} MB", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { scope.launch { killApp(p.pkg); list = loadProcs(ctx) } }) { Text("Kill") }
                }
            }
        }
    }
}

@Composable
fun BootTab(ok: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<Boot>()) }
    LaunchedEffect(ok) { list = loadBoot(ctx) }
    Column {
        Text("Interruttore ON = l'app può avviarsi al boot. OFF = receiver disattivato.",
            Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
        LazyColumn {
            items(list, key = { it.pkg + it.cls }) { b ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.label)
                        Text(b.pkg, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = b.on, enabled = ok, onCheckedChange = { v ->
                        scope.launch { setBoot(b, v); list = loadBoot(ctx) }
                    })
                }
            }
        }
    }
}
