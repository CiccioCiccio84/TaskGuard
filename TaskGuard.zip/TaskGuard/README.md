# TaskGuard
App Android con ADB integrato (debug wireless), senza Shizuku.
1. Installa l'APK (vedi workflow GitHub Actions).
2. Nell'app: scheda Processi/Autostart > segui i passaggi di associazione (una sola volta).
3. Dopo ogni riavvio o cambio Wi-Fi: Debug wireless ON e premi "Connetti".
