package it.ciccio.taskguard

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.conscrypt.Conscrypt
import sun.security.x509.AlgorithmId
import sun.security.x509.CertificateAlgorithmId
import sun.security.x509.CertificateExtensions
import sun.security.x509.CertificateIssuerName
import sun.security.x509.CertificateSerialNumber
import sun.security.x509.CertificateSubjectName
import sun.security.x509.CertificateValidity
import sun.security.x509.CertificateVersion
import sun.security.x509.CertificateX509Key
import sun.security.x509.KeyIdentifier
import sun.security.x509.PrivateKeyUsageExtension
import sun.security.x509.SubjectKeyIdentifierExtension
import sun.security.x509.X500Name
import sun.security.x509.X509CertImpl
import sun.security.x509.X509CertInfo
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Security
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random

/** Gestore ADB: chiave e certificato vengono salvati, così l'associazione resta valida. */
class AdbMgr private constructor(ctx: Context) : AbsAdbConnectionManager() {
    private val key: PrivateKey
    private val crt: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key")
        val cf = File(ctx.filesDir, "adb_cert")
        var k: PrivateKey? = null
        var c: Certificate? = null
        try {
            if (kf.exists() && cf.exists()) {
                k = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                c = CertificateFactory.getInstance("X.509").generateCertificate(cf.inputStream())
            }
        } catch (e: Throwable) { k = null; c = null }
        if (k == null || c == null) {
            val g = KeyPairGenerator.getInstance("RSA")
            g.initialize(2048, SecureRandom())
            val kp = g.generateKeyPair()
            val pub = kp.public
            val priv = kp.private
            val alg = "SHA512withRSA"
            val nb = Date()
            val na = Date(System.currentTimeMillis() + 3650L * 86400000L)
            val ext = CertificateExtensions()
            ext.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(pub).identifier))
            val name = X500Name("CN=TaskGuard")
            ext.set("PrivateKeyUsage", PrivateKeyUsageExtension(nb, na))
            val info = X509CertInfo()
            info.set("version", CertificateVersion(2))
            info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
            info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(alg)))
            info.set("subject", CertificateSubjectName(name))
            info.set("key", CertificateX509Key(pub))
            info.set("validity", CertificateValidity(nb, na))
            info.set("issuer", CertificateIssuerName(name))
            info.set("extensions", ext)
            val cert = X509CertImpl(info)
            cert.sign(priv, alg)
            kf.writeBytes(priv.encoded)
            cf.writeBytes(cert.encoded)
            k = priv
            c = cert
        }
        key = k!!
        crt = c!!
    }

    override fun getPrivateKey(): PrivateKey = key
    override fun getCertificate(): Certificate = crt
    override fun getDeviceName(): String = "TaskGuard"

    companion object { fun create(ctx: Context) = AdbMgr(ctx) }
}

object Adb {
    private var inited = false
    @Volatile private var mgr: AdbMgr? = null

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
        mgr = AdbMgr.create(ctx.applicationContext)
        inited = true
    }

    fun connected(): Boolean = try { mgr?.isConnected == true } catch (e: Throwable) { false }

    fun connect(ctx: Context): String = try {
        init(ctx)
        if (!connected()) mgr!!.autoConnect(ctx, 8000)
        if (connected()) "Connesso" else "Connessione non riuscita: controlla che Debug wireless e Wi-Fi siano attivi"
    } catch (e: Throwable) { "Errore: ${e.message}" }

    fun pair(ctx: Context, port: Int, code: String): String = try {
        init(ctx)
        val r: Any? = mgr!!.pair("127.0.0.1", port, code)
        if (r == false) "Associazione fallita: controlla porta e codice" else "Associato. Ora premi Connetti"
    } catch (e: Throwable) { "Errore: ${e.message}" }

    fun run(cmd: String): String {
        val m = mgr ?: return ""
        return try {
            val s = m.openStream("shell:$cmd")
            try { s.openInputStream().bufferedReader().readText() } finally { s.close() }
        } catch (e: Throwable) { "" }
    }
}

/** Trova da solo la porta di associazione mostrata dalle Impostazioni. */
class PairDiscovery(ctx: Context, private val onPort: (Int) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val l = object : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(t: String) {}
        override fun onServiceFound(i: NsdServiceInfo) {
            nsd.resolveService(i, object : NsdManager.ResolveListener {
                override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                override fun onServiceResolved(s: NsdServiceInfo) { onPort(s.port) }
            })
        }
        override fun onServiceLost(i: NsdServiceInfo) {}
        override fun onDiscoveryStopped(t: String) {}
        override fun onStartDiscoveryFailed(t: String, e: Int) {}
        override fun onStopDiscoveryFailed(t: String, e: Int) {}
    }
    fun start() { try { nsd.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, l) } catch (e: Throwable) {} }
    fun stop() { try { nsd.stopServiceDiscovery(l) } catch (e: Throwable) {} }
}
