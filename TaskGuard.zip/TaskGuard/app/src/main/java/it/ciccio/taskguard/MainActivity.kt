package it.ciccio.taskguard

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var ok by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { Adb.init(ctx) }
        while (true) { ok = Adb.connected(); delay(4000) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            listOf("Salute", "Processi", "Autostart").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }) { Text(t, Modifier.padding(12.dp)) }
            }
        }
        when {
            tab == 0 -> Health()
            !ok -> ConnectPanel { ok = Adb.connected() }
            tab == 1 -> Procs(ok)
            else -> BootTab(ok)
        }
    }
}

@Composable
fun ConnectPanel(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val d = PairDiscovery(ctx) { port = it.toString() }
        d.start()
        onDispose { d.stop() }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Non connesso al debug wireless", style = MaterialTheme.typography.titleMedium)
        Text(
            "1) Collegati al Wi-Fi e attiva Debug wireless nelle Opzioni sviluppatore.\n" +
            "2) Tocca \"Associa dispositivo con codice\": appaiono porta e codice a 6 cifre. " +
            "La finestra si chiude se esci dalle Impostazioni: usa lo schermo diviso " +
            "(Recenti > icona dell'app > Schermo diviso) con TaskGuard accanto.\n" +
            "3) Scrivi il codice qui sotto e premi Associa (la porta si compila da sola).\n" +
            "4) Premi Connetti. L'associazione si fa una volta sola.",
            Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Apri Opzioni sviluppatore") }
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(port, { port = it }, label = { Text("Porta") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(code, { code = it }, label = { Text("Codice") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                scope.launch {
                    msg = "Associazione in corso…"
                    msg = withContext(Dispatchers.IO) { Adb.pair(ctx, port.toIntOrNull() ?: 0, code.trim()) }
                    onChanged()
                }
            }) { Text("Associa") }
            Button(onClick = {
                scope.launch {
                    msg = "Connessione in corso…"
                    msg = withContext(Dispatchers.IO) { Adb.connect(ctx) }
                    onChanged()
                }
            }) { Text("Connetti") }
        }
        if (msg.isNotEmpty()) Text(msg, Modifier.padding(top = 12.dp))
    }
}

@Composable
fun Info(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
    Text(k, Modifier.weight(1f)); Text(v)
}

@Composable
fun Health() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(3000); tick++ } }
    val rows = remember(tick) {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = (b?.getIntExtra("level", 0) ?: 0) * 100 / (b?.getIntExtra("scale", 100) ?: 100)
        val temp = (b?.getIntExtra("temperature", 0) ?: 0) / 10.0
        val health = when (b?.getIntExtra("health", 1)) {
            2 -> "Buona"; 3 -> "Surriscaldata"; 4 -> "Esaurita"; 5 -> "Sovratensione"; else -> "Sconosciuta"
        }
        val charging = (b?.getIntExtra("plugged", 0) ?: 0) != 0
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ramTot = mi.totalMem / 1048576
        val ramUsed = ramTot - mi.availMem / 1048576
        val sf = StatFs(Environment.getDataDirectory().path)
        val stTot = sf.totalBytes / 1073741824.0
        val stUsed = stTot - sf.availableBytes / 1073741824.0
        listOf(
            "Batteria" to "$lvl%" + if (charging) " (in carica)" else "",
            "Temperatura batteria" to "%.1f °C".format(temp),
            "Salute batteria" to health,
            "RAM" to "$ramUsed / $ramTot MB",
            "Archiviazione" to "%.1f / %.1f GB".format(stUsed, stTot),
        )
    }
    Column(Modifier.padding(top = 8.dp)) { rows.forEach { (k, v) -> Info(k, v); HorizontalDivider() } }
}

@Composable
fun Procs(ok: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<Proc>()) }
    fun refresh() { if (ok) scope.launch { list = loadProcs(ctx) } }
    LaunchedEffect(ok) { refresh() }
    Column {
        Button(onClick = { refresh() }, modifier = Modifier.padding(8.dp)) { Text("Aggiorna") }
        LazyColumn {
            items(list, key = { it.pkg }) { p ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.label)
                        Text("${p.pkg} · ${p.mb} MB", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { scope.launch { killApp(p.pkg); list = loadProcs(ctx) } }) { Text("Kill") }
                }
            }
        }
    }
}

@Composable
fun BootTab(ok: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<Boot>()) }
    LaunchedEffect(ok) { list = loadBoot(ctx) }
    Column {
        Text("Interruttore ON = l'app può avviarsi al boot. OFF = receiver disattivato.",
            Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
        LazyColumn {
            items(list, key = { it.pkg + it.cls }) { b ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.label)
                        Text(b.pkg, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = b.on, enabled = ok, onCheckedChange = { v ->
                        scope.launch { setBoot(b, v); list = loadBoot(ctx) }
                    })
                }
            }
        }
    }
}
