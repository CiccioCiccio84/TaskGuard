package it.ciccio.taskguard

import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Esegue comandi shell tramite l'ADB integrato (debug wireless). */
object Sh {
    fun ready(): Boolean = Adb.connected()
    fun run(cmd: String): String = Adb.run(cmd)
}

data class Proc(val pkg: String, val label: String, val mb: Int)
data class Boot(val pkg: String, val cls: String, val label: String, val on: Boolean)

suspend fun loadProcs(ctx: Context): List<Proc> = withContext(Dispatchers.IO) {
    val pm = ctx.packageManager
    Sh.run("ps -A -o PID,RSS,NAME").lines().drop(1).mapNotNull { l ->
        val p = l.trim().split(Regex("\\s+"))
        if (p.size < 3) return@mapNotNull null
        val pkg = p[2].substringBefore(':')
        val ai = try { pm.getApplicationInfo(pkg, 0) } catch (e: Exception) { return@mapNotNull null }
        if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || pkg == ctx.packageName) return@mapNotNull null
        Proc(pkg, pm.getApplicationLabel(ai).toString(), (p[1].toIntOrNull() ?: 0) / 1024)
    }.groupBy { it.pkg }
        .map { (k, v) -> Proc(k, v[0].label, v.sumOf { it.mb }) }
        .sortedByDescending { it.mb }
}

suspend fun loadBoot(ctx: Context): List<Boot> = withContext(Dispatchers.IO) {
    val pm = ctx.packageManager
    pm.queryBroadcastReceivers(Intent(Intent.ACTION_BOOT_COMPLETED), PackageManager.MATCH_DISABLED_COMPONENTS)
        .mapNotNull { r ->
            val ai = r.activityInfo
            val app = ai.applicationInfo
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || ai.packageName == ctx.packageName)
                return@mapNotNull null
            val s = pm.getComponentEnabledSetting(ComponentName(ai.packageName, ai.name))
            val on = s == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                (s == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && ai.enabled)
            Boot(ai.packageName, ai.name, pm.getApplicationLabel(app).toString(), on)
        }.sortedBy { it.label.lowercase() }
}

suspend fun killApp(pkg: String) = withContext(Dispatchers.IO) { Sh.run("am force-stop $pkg") }

suspend fun setBoot(b: Boot, enable: Boolean) = withContext(Dispatchers.IO) {
    Sh.run("pm ${if (enable) "enable" else "disable"} --user 0 '${b.pkg}/${b.cls}'")
}
